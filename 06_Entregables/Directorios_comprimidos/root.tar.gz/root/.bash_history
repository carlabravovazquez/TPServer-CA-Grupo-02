history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
shutdown -h now
whatis hostname hostnamectl
man hostnamectl
man hostname
hostnamectl
hostnamectl set-hostname TPServer
hostnamectl
cat /etc/hosts
vi /etc/hosts
cat /etc/hosts
shutdown -r now
history
shutdown -h now
lsb_realease -a
clean
lsb_release -a
cat /etc/debian_version
cat /etc/apt/sources.list
apt update
ip a
ping 8.8.8.8
ping deb.bedian.org
ping deb.debian.org
cp /etc/apt/sources.list /etc/apt/sources.list.orig
vi /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt upgrade
cat /etc/debian_version
vi /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt full-upgrade
apt autoremove
reboot
lsb_release -a
cat /etc/debian_version
history
shutdown -h now
exit
exit
systemctl status ssh
grep Accepted /var/log/auth.log
history
shutdown -h now
apt show apache2
apt show -a apache2
apt show php
apt-cache search libapache2-mod-php
apt-cache search php-mysql
apt-cache search php-mysql
apt-get install apache2 php libapache2-mod-php php-mysql
systemctl status apache2
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
ls -l /var/www/html
cp /root/Material_Adicional_TPVMCA/index.php /root/Material_Adicional_TPVMCA/logo.png  /var/www/html/
mv /var/www/html/index.html /var/www/html/index.html.orig
ls -l /var/www/html
grep PHP /var/log/apache2/error.log 
history
shutdown -h now
ip a
ip route
cat /etc/resolv.conf
cat /etc/network/interfaces
cp /etc/network/interfaces /etc/network/interfaces.orig
vi /etc/network/interfaces
cat /etc/network/interfaces
shutdown -r now
ip a
vi /etc/network/interfaces
cat /etc/network/interfaces
shutdown -r now
exit
ip a
ip route
ip route 8.8.8.8
ping 8.8.8.8
ip route
ping 8.8.8.8
ping deb.debian.org
history
shutdown -h now
lsblk
fdisk /dev/sdc
lsblk
mkfs -t ext4 /dev/sdc1
mkfs -f ext4 /dev/sdc2
mkfs -t ext4 /dev/sdc2
mkdir /www_dir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
cp /etc/fstab /etc/fstab.orig
cat /etc/fstab
vi /etc/fstab
cat /etc/fstab
umount /www_dir /backup_dir
df -h
mount -a
df -h
systemctl daemon-reload
cp /root/Material_Adicional_TPVMCA/index.php /root/Material_Adicional_TPVMCA/logo.png /www_dir/
ls -l /www_dir/
cp /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-available/000-default.conf.orig
cp /etc/apache2/apache2.conf /etc/apache2/apache2.conf.orig
vi /etc/apache2/sites-available/000-default.conf
grep -n "Directory /var/www" /etc/apache2/apache2.conf
vi /etc/apache2/apache2.conf
ls -l /etc/apache2/apache2.conf*
grep -n "Directory /var/www" /etc/apache2/apache2.conf
vi /etc/apache2/apache2.conf
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
grep "Directory /www_dir" /etc/apache2/apache2.conf
systemctl restart apache2
systemctl status apache2
umount /www_dir
ls -l /www_dir
mount -a
ls -l /www_dir
cat /proc/partitions 
cat /proc/partitions > /opt/particion
ls -l /opt
cat /opt/particion 
shutdown -r now
df -h
cat /opt/particion 
history
shutdown -h now
mkdir /opt/scripts
vi /opt/scripts/backup_full.sh
chmod 755 /opt/scripts/backup_full.sh 
ls -l /opt/scripts/
/opt/scripts/backup_full.sh  -help
/opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh /noexiste /backup_dir
/opt/scripts/backup_full.sh  /var/log /noexiste
history
shutdown -h now
ls -l /opt/scripts
df -h
umont /www_dir
umount /www_dir
/opt/scripts/backup_full.sh /www_dir /backup_dir
mount -a
/opt/scripts/backup_full.sh /var/log /backup_dir
ls -l /backup_dir
/opt/scripts/backup_full.sh /www_dir /backup_dir
ls -l /backup_dir
systemctl status cron
crontab -e
crontab -l
systemctl status cron
history
shutdown -h now
